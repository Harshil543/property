import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { HomeContext } from "./HomeContext";

const HomeList = () => {
  const { homes, deleteHome } = useContext(HomeContext);

  return (
    <div className="m-5">
      <h2>Homes</h2>
      <table className="table align-middle">
        <thead>
          <tr>
            <th>Title</th>
            <th>Street</th>
            <th>City</th>
            <th>State</th>
            <th>Country</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {homes.map((home, index) => (
            <tr key={index}>
              <td>{home.title}</td>
              <td>{home.street}</td>
              <td>{home.city}</td>
              <td>{home.state}</td>
              <td>{home.country}</td>
              <td>
                <Link
                  className="btn btn-dark text-light me-2"
                  to={`/edit/${index}`}
                >
                  Edit
                </Link>
                <button
                  className="btn btn-dark text-light"
                  onClick={() => deleteHome(index)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default HomeList;
