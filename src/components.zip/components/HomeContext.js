import { createContext } from "react";
import React, { useState } from "react";

export const HomeContext = createContext();

export const HomeProvider = ({ children }) => {
  const [homes, setHomes] = useState(
    JSON.parse(localStorage.getItem("homes")) || []
  );

  const addHome = (homeData) => {
    const updatedHomes = [...homes, homeData];
    setHomes(updatedHomes);
    localStorage.setItem("homes", JSON.stringify(updatedHomes));
  };

  const editHome = (index, homeData) => {
    const updatedHomes = [...homes];
    updatedHomes[index] = homeData;
    setHomes(updatedHomes);
    localStorage.setItem("homes", JSON.stringify(updatedHomes));
  };

  const deleteHome = (index) => {
    const updatedHomes = homes.filter((_, i) => i !== index);
    setHomes(updatedHomes);
    localStorage.setItem("homes", JSON.stringify(updatedHomes));
  };

  return (
    <HomeContext.Provider value={{ homes, addHome, editHome, deleteHome }}>
      {children}
    </HomeContext.Provider>
  );
};
